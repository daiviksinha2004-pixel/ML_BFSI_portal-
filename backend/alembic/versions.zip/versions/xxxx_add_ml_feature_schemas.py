"""add ml_feature_schemas table

Revision ID: a1b2c3d4e5f6
Revises: <your_last_revision_id>
Create Date: 2026-04-03
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = 'a1b2c3d4e5f6'
down_revision = '<your_last_revision_id>'   # ← replace with your actual last rev
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'ml_feature_schemas',
        sa.Column('id',            postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('model_name',    sa.String(100),  nullable=False),
        sa.Column('feature_names', postgresql.JSONB, nullable=False),
        sa.Column('imputer_cols',  postgresql.JSONB, nullable=False),
        sa.Column('all_nan_cols',  postgresql.JSONB, nullable=False),
        sa.Column('raw_columns',   postgresql.JSONB, nullable=False),
        sa.Column('drop_cols',     postgresql.JSONB, nullable=False),
        sa.Column('metrics',       postgresql.JSONB, nullable=True),
        sa.Column('trained_at',    sa.DateTime(timezone=True),
                  server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at',    sa.DateTime(timezone=True),
                  server_default=sa.text('now()'), nullable=False),
    )
    op.create_index('ix_ml_feature_schemas_model_name',
                    'ml_feature_schemas', ['model_name'], unique=True)


def downgrade() -> None:
    op.drop_index('ix_ml_feature_schemas_model_name',
                  table_name='ml_feature_schemas')
    op.drop_table('ml_feature_schemas')